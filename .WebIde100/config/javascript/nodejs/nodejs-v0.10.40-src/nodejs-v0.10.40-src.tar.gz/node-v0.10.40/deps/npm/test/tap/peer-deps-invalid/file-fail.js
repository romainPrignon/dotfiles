/**package
* { "name": "npm-test-peer-deps-file-invalid"
* , "main": "index.js"
* , "version": "1.2.3"
* , "description":"This one should conflict with the other one"
* , "peerDependencies": { "underscore": "1.3.3" }
* }
**/

module.exports = "I\'m just a lonely index, naked as the day I was born."
